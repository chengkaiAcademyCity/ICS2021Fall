#! /bin/bash

set -e

gcc -o exp handin.c -lpthread

rm -f log.txt
for n in {0..1}
do
	./exp >> log.txt &
	sleep 0.5s
done

C="`cat log.txt | grep "You win" | wc -l`"

if [ $C == "0" ]; then
	echo "Failure: Failed to print the wanted string."
else
	echo "Success: Your string is correct."
fi

killall -9 exp || true
