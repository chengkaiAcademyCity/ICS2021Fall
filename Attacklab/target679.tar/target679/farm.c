/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_362(unsigned *p)
{
    *p = 2462550344U;
}

void setval_310(unsigned *p)
{
    *p = 3347671293U;
}

void setval_323(unsigned *p)
{
    *p = 3281279182U;
}

void setval_279(unsigned *p)
{
    *p = 2421719261U;
}

void setval_478(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_210()
{
    return 3347662954U;
}

void setval_160(unsigned *p)
{
    *p = 2420641951U;
}

unsigned addval_125(unsigned x)
{
    return x + 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_242()
{
    return 3286272840U;
}

void setval_421(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_392(unsigned x)
{
    return x + 3525886345U;
}

void setval_465(unsigned *p)
{
    *p = 3286272072U;
}

void setval_394(unsigned *p)
{
    *p = 3525362057U;
}

unsigned addval_187(unsigned x)
{
    return x + 2429192510U;
}

unsigned addval_357(unsigned x)
{
    return x + 3221801673U;
}

void setval_341(unsigned *p)
{
    *p = 3224950441U;
}

unsigned addval_414(unsigned x)
{
    return x + 3525364377U;
}

void setval_441(unsigned *p)
{
    *p = 3402216799U;
}

void setval_329(unsigned *p)
{
    *p = 2447411528U;
}

void setval_468(unsigned *p)
{
    *p = 2430635336U;
}

unsigned getval_235()
{
    return 3284244785U;
}

void setval_481(unsigned *p)
{
    *p = 3222850185U;
}

unsigned addval_345(unsigned x)
{
    return x + 684179849U;
}

unsigned addval_291(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_484()
{
    return 2430634312U;
}

unsigned getval_152()
{
    return 3375417993U;
}

unsigned addval_398(unsigned x)
{
    return x + 3675838089U;
}

unsigned addval_275(unsigned x)
{
    return x + 3675835017U;
}

void setval_201(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_209()
{
    return 2428600715U;
}

void setval_104(unsigned *p)
{
    *p = 3380134281U;
}

unsigned getval_487()
{
    return 3281046153U;
}

unsigned getval_165()
{
    return 3525891721U;
}

void setval_498(unsigned *p)
{
    *p = 3677410953U;
}

void setval_245(unsigned *p)
{
    *p = 3523794568U;
}

unsigned getval_338()
{
    return 3380920713U;
}

void setval_409(unsigned *p)
{
    *p = 3368277657U;
}

unsigned addval_471(unsigned x)
{
    return x + 2546194057U;
}

unsigned addval_106(unsigned x)
{
    return x + 3380926089U;
}

unsigned getval_264()
{
    return 3682124169U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
